<html>
<head>
<title>See your appointment</title>
 <link rel="stylesheet" type="text/css" href="s3.css">
</head>
<body>
	<center>
		<form action="" method="POST">
			<label><h1>Enter Your Email</h1></label><br />
			<input type="text" name="Email" placeholder="Enter Your Email"/> <br/>
			<input type="text" name="Symtoms" placeholder="Symtoms"/> <br/>
			<input type="submit" name="Search" value="Search Data"/><br/> 
			<input type="submit" name="Fix" value="Fix a new Appointment"/>
		</form>
<?php 
	session_start();
	$connection = mysqli_connect("localhost","root","");
	$db = mysqli_select_db($connection,'medical');
	if(isset($_POST['Search']))
	{
	$Email = $_POST['Email'];
	$Symtoms=$_POST['Symtoms'];
	// $date="null";
	$query = "SELECT * FROM medical1 WHERE Email='$Email'; ";
	$query_run=mysqli_query($connection,$query);

       if(isset($_POST['Fix'])){
	$query = "UPDATE medical1 SET Symtoms='$Symtoms',Date='' WHERE Email='$Email'; ";
	$query_run=mysqli_query($connection,$query);
}
	while($row = mysqli_fetch_array($query_run)){
	?>
		<form action="" method="POST">
		<input type="hidden" name="id" value="<?php echo $row['id']?>" /><br>
		<input disabled type="text" name="Name" value="<?php echo $row['Name']?>"  /><br>
		<input disabled type="text" name="Location" value="<?php echo $row['Location']?>"  /><br>
		<input disabled type="text" name="Symtoms" value="<?php echo $row['Symtoms']?>" /><br>
		<input disabled type="text" name="Email" value="<?php echo $row['Email']?>"  /><br>
		<input disabled type="text" name="Date" value="<?php echo $row['Date']?>"  /><br>
	<?php
	
}
}
?>
<!-- <?php
$Email = $_POST['Email'];
$Symtoms=$_POST['Symtoms'];
//$date="null";

if(isset($_POST['Fix'])){
$query1 = "UPDATE medical1 SET Symtoms='$Symtoms',Date='$date' WHERE Email='$Email'; ";
$query_run1=mysqli_query($connection,$query1);
}

?> -->
	</center>
</body>
</html>