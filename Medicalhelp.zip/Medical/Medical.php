<!DOCTYPE html>
<html>
<center>
<head>
  <title>Medical Help</title>
  <link rel="stylesheet" type="text/css" href="style.css">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css"
        integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body style="background-image: url('medical.jpg'); background-size:cover;">
<?php require_once 'server.php';
if(isset($_SESSION['message'])):
    ?>
    <div style="text-align:center;" class="alert alert-warning">
        <?php 
        echo $_SESSION['message'];
        $_SESSION['message']=null;
        ?>
    </div>
    <?php endif; ?>
  <div class="header" >
  	<h2>Medical help</h2>
 		</div>
  <form autocomplete="off" method="post" action="Medical.php" style="background: white;color: black;width: 400px; border-radius: 5px" >
  	<div class="input-group">
  	  <label>Name</label>
  	  <input type="text" name="Name" value="">
    </div>
	<div class="input-group">
  	  <label>Location</label>
  	  <input type="text" name="Location" value="">
  	</div>
    <div style="text-align: left;">
  	  <label>Gender:</label><br>
  	  <input type="Radio" name="gender" value="male"> Male
	  <input type="Radio" name="gender" value="female" > Female
	<div class="input-group">
  	  <label>Symtoms</label>
  	  <input type="text" name="Symtoms" value="">
  	</div>
	<div class="input-group">
  	  <label>Phone Number</label>
  	  <input type="" name="Ph" value="" pattern="[0-9]{10}">
  	</div>
	<div class="input-group">
  	  <label>Email</label>
  	  <input type="EMAIL" name="Email" value="">
  	</div>
  	<div class="input-group">
  	  <button type="submit" class="btn" name="reg_user">Register</button>
	  <a href="Medical.php"><button style="margin-left:10px;" type="submit" class="btn">Clear</button></a>
  	</div>
	<p><a href="Dlogin.php">Doctor's Login</a><br>
    New Doctor?<a href="dsignup.php">Click here</a><br>
	 Already Registered? <a href="show.php">Click here</p>
	</div>	

  </form>
</body>
</center>
</html>