<?php
 session_start();
if(isset($_POST['reg_user'])){

	$Name = $_POST['Name'];
	$Location = $_POST['Location'];
	$gender = $_POST['gender'];
	$Symtoms = $_POST['Symtoms'];
	$Ph = $_POST['Ph'];
	$Email = $_POST['Email'];
	$conn = new mysqli('localhost','root','','medical');
	if($conn->connect_error){
		echo "$conn->connect_error";
		die("Connection Failed : ". $conn->connect_error);
	} else {
		$conn->query("INSERT INTO medical1 (Name,Location,gender,Symtoms,Phone,Email) VALUES ('$Name','$Location','$gender','$Symtoms','$Ph','$Email')") or die($conn->error);
		if($Symtoms=='fever'){
	$_SESSION['message'] = 'Have u tried paracetomal';
	}
	if($Symtoms=='cold'){
	$_SESSION['message'] = 'Have u tried paracetomal';
	}
	if($Symtoms=='headache'){
	$_SESSION['message'] = 'Have u tried Disprin';
	}
	}
}
?>