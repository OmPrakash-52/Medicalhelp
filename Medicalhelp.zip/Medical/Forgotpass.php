 <?php
 
 require 'phpmailer/PHPMailerAutoload.php'; //path
    $mail = new PHPMailer;

    $email = "omp30583@gmail.com"; //email where you want to send

    $mail->isSMTP(); //for localhost not liveserver
//if you using latest version of PHP 
$mail->SMTPOptions = array(
'ssl' => array(
'verify_peer' => false,
'verify_peer_name' => false,
'allow_self_signed' => true
)
);

    $mail->Host = 'smtp.gmail.com';
    $mail->port = 587;
    $mail->SMTPAuth = true;
    $mail->SMTPSecure = 'tls';
    $mail->Username = 'medicalhelp142@gmail.com'; //your email id
    $mail->Password = 'hello@world12'; //your email password
    $mail->setFrom('medicalhelp142@gmail.com','Name');
    $mail->addAddress($email);
    $mail->addReplyTo('no-reply'); // if you want to reply by user then you can place your email id

    $mail->isHTML(true); //for html
    $mail->Subject = 'OTP to forgot password'; //subject
    
$mail->Body = '<h1 align="center"> hello, your message body </h1>';

if(!$mail->send()) {
        //mail not send
        echo "Mail not send";
    }
    else {
       //mail send
        echo "Mail send";
    }
?>