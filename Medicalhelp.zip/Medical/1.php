<!DOCTYPE html>
<html>
<head>
	<title>Name - 1ME17CS0</title>
	<style>
		table,td,th
		{
			border: 1px solid black;
			width: 33%;
			text-align:center;
			background-color: darkgrey;
			border-collapse: collapse;
		}
		table{margin:auto;}
		input{text-align:right;}
	</style>
	<script type="text/javascript">
		function calc(clicker_id) 
		{
			var val1=parseFloat(document.getElementById("value1").value);
			var val2=parseFloat(document.getElementById("value2").value);

			if(isNaN(val1)||isNaN(val2))
				alert("Enter Numbers");
			else if(clicker_id=="add")
				document.getElementById("answer").value=val1+val2;
			else if(clicker_id=="sub")
				document.getElementById("answer").value=val1-val2;
			else if(clicker_id=="mul")
				document.getElementById("answer").value=val1*val2;
			else if(clicker_id=="div")
				document.getElementById("answer").value=val1/val2;
		}
		function cls() {
			value1.value="0";
			value2.value="0";
			answer.value="0";
		}
	</script>
</head>
<body>
	<table>
		<tr><th colspan="4">Simple Calcy</th></tr>
		<tr><td>value1</td><td><input type="text" value="0" id="value1"></td>
			<td>value2</td>
			<td><input type="text" value="0" id="value2"></td>
		</tr>
		<tr>
			<td><input type="button" value="addition" id="add" onclick="calc(this.id)"/>
			</td>
			<td><input type="button" value="substraction" id="sub" onclick="calc(this.id)"/>
			</td>
			<td><input type="button" value="multiplication" id="mul" onclick="calc(this.id)"/>
			</td>
			<td><input type="button" value="division" id="div" onclick="calc(this.id)"/>
			</td>
		</tr>
		<tr>
			<td>Result:</td>
			<td>
				<input type="text" id="answer" value="0" disabled/>
			</td>
			<td colspan="2">
				<input type="button" onclick="cls()" value="Clear all"/>
			</td>
		</tr>
	</table>
</body>
</html>