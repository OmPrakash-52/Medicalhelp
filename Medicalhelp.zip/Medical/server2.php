<?php
 session_start();
	$conn = new mysqli('localhost','root','','medical');
	if(isset($_GET['id'])){

	$ids = $_GET['id'];
	
	
	$s="SELECT * FROM medical1 WHERE id=$ids";
	$result=$conn->query($s) or die($conn->error);
	$num=$result->fetch_array();

}


if(isset($_POST['Upd'])){
	
        $idss = $_GET['id'];
	$Name = $_POST['Name'];
	$Location = $_POST['Location'];
	$gender= $_POST['gender'];
	$Symtoms = $_POST['Symtoms'];
	$Ph=$_POST['Ph'];
	$Email = $_POST['Email'];
	$Date = $_POST['Date'];
	
	$v="UPDATE medical1 SET Name='$Name',Location='$Location',gender='$gender',Symtoms='$Symtoms',Phone='$Ph',Email='$Email',Date='$Date' WHERE id=$idss ";
	$r=$conn->query($v);
	if($r){
	 require 'phpmailer/PHPMailerAutoload.php'; //path
    $mail = new PHPMailer;

    //$email = .$Email.; //email where you want to send

    $mail->isSMTP(); //for localhost not liveserver
//if you using latest version of PHP 
$mail->SMTPOptions = array(
'ssl' => array(
'verify_peer' => false,
'verify_peer_name' => false,
'allow_self_signed' => true
)
);

    $mail->Host = 'smtp.gmail.com';
    $mail->port = 587;
    $mail->SMTPAuth = true;
    $mail->SMTPSecure = 'tls';
    $mail->Username = 'medicalhelp142@gmail.com'; //your email id
    $mail->Password = 'hello@world12'; //your email password
    $mail->setFrom('medicalhelp142@gmail.com','Medicalhelp');
    $mail->addAddress($Email);
    $mail->addReplyTo('no-reply'); // if you want to reply by user then you can place your email id

    $mail->isHTML(true); //for html
    $mail->Subject = 'Your Time and date of Appointment'; //subject
    
$mail->Body = '<h1 align="center"> hello,Your Time and date of Appointment is at '.$Date.' With Doctor '.$_SESSION['dname'].' </h1>';

if(!$mail->send()) {
        //mail not send
        echo "Mail not send";
	echo $Email;
    }
    else {
       //mail send
        header('location:next.php');
    } }else{ die($conn->error);}
	//header("location:next1.php?id=".$idss);
	
}
if(isset($_GET['delete'])){
	$id=$_GET['delete'];
	$conn->query("DELETE FROM medical1 WHERE id='$id'") or die($conn->error);
	header('location:next.php');
}
?>