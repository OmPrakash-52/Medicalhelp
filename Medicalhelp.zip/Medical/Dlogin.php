<!DOCTYPE html>
<html>
<head>
  <title>DOCTOR LOGIN</title>
  <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body style="background-image: url('medical12.jpg'); background-size:cover;">

<?php require_once 'server1.php';?>
  <div class="header">
  	<h2>DOCTOR LOGIN</h2>
  </div>
	
  <form class="header" method="post" action="Dlogin.php" style="color: black; background: #ffffff; border:1px solid black;">
  	<div class="input-group">
  	  <label>Name</label>
  	  <input name="Name" value="">
  	</div>
	<div class="input-group">
  	  <label>Password</label>
  	  <input type="Password" name="Password" value="">
  	</div>
  	<div class="input-group">
  	  <button type="submit" class="btn" name="Lo">Login</button>
  	</div>
	
  </form>
</body>
</html>