
<!DOCTYPE html>
<html>

<link rel="stylesheet" type="text/css" href="style2.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css" integrity="sha512-+4zCK9k+qNFUR5X+cKL9EIR+ZOhtIloNl9GIKS57V1MyNsYpYcUrUeQc9vNfzsWfV28IaLL3i96P9sdNyeRssA==" crossorigin="anonymous" />

<head>
	<title></title>
</head>
<body background=#0e0930>
<div class="main-div">
	<h1 align="center">LIST OF PATIENTS</h1>
	<div class="center-div">
	<div clas="table-responsive">
		<table>
			<thead>
			<tr>
			   <th>id</th>
			   <th>Name</th>
   			   <th>Location</th>
			   <th>Gender</th>
			   <th>Symtoms</th>
			   <th>Phone</th>
			   <th>E-mail</th>
			   <th>Appointment</th>
			   <th colspan="2">Operation</th>
			</tr>
			</thead>
			<tbody>
			<?php
 			session_start();
			$conn = new mysqli('localhost','root','','medical');
			$s="SELECT * FROM medical1 ";
			$result=mysqli_query($conn,$s);
			$num=mysqli_num_rows($result);
			while($res = mysqli_fetch_array($result)){
?>
			
			<tr>
				<td><?php echo $res['id']; ?></td>
				<td><?php echo $res['Name']; ?></td>
				<td><?php echo $res['Location']; ?></td>
				<td><?php echo $res['gender']; ?></td>
				<td><?php echo $res['Symtoms']; ?></td>
				<td><?php echo $res['Phone']; ?></td>
				<td><?php echo $res['Email']; ?></td>
				<td><?php echo $res['Date']; ?></td>
				<td><a href="next1.php?id=<?php echo $res['id']; ?>" data-toggle="tooltip" data-placement="top" title="Update"><i class="fa fa-edit" aria-hidden="true"></i></a></td>
				<td><a href="server2.php?delete=<?php echo $res['id']; ?>" onclick="return confirm('Are You Sure')"><i class="fa fa-trash" aria-hidden="true"></i></button></td>
				</tr>;
<?php
}

?>
			</tbody>
		</table>
	
	</div>
	</div>
	<br><center><font size="5px"><a style="color: #b3190e" href="Medical.php"><b>Logout</b></a></font></center>
</div>
</body>
</html>