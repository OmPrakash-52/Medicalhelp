<html>
<head>
<title>hello</title>
</head>
<body>
<center>
	<form class="form-group" action="hello.php">
	<label>Name</label>
  	  <input name="Name" value="">
	<button type="submit" class="btn" name="lp" >Register</button>
	</form>
</center>
<script>
<?php
	if(isset($_POST['lp'])){

	$Name = $_POST['Name'];
	if($Name == fever){
	alert("hello");
	}
}?></script>
</body>
</html>