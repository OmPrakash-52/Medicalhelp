<!DOCTYPE html>
<html>
<head>
  <title>Update</title>
  <link rel="stylesheet" type="text/css" href="style.css">
  
</head>
<body>
<?php require_once 'server2.php'; ?>
  <div class="header">
  	<h2>Update</h2>
  </div>
 <?php  
    $m=$f="";
if($num['gender'] == 'male'){
 $m="checked";
}elseif($num['gender'] == 'female'){
$f="checked";
}

?>	
  <form class="header" method="post" style="color:black; background-color:white;width: 400px; border-radius: 5px ">
  	<div class="input-group">
  	  <label>Name</label>
  	  <input name="Name" value="<?php echo $num['Name']; ?>" Placeholder="hello">
  	</div>
	<div class="input-group">
  	  <label>Location</label>
  	  <input name="Location" value="<?php echo $num['Location']; ?>">
  	</div>
    <div style="text-align: left;">
  	  <label>Gender:</label><br>
  	  <input type="Radio" name="gender" value="male" value="<?php echo $num['gender']; ?>"<?php echo $m; ?>> Male
	  <input type="Radio" name="gender" value="female" value="<?php echo $num['gender']; ?>"<?php echo $f; ?>> Female
  </div>
	<div class="input-group">
  	  <label>Symtoms</label>
  	  <input name="Symtoms" value="<?php echo $num['Symtoms']; ?>">
  	</div>
	<div class="input-group">
  	  <label>Phone Number</label>
  	  <input type="" name="Ph" value="<?php echo $num['Phone']; ?>" pattern="[0-9]{10}">
  	</div>
	<div class="input-group">
  	  <label>Email</label>
  	  <input type="EMAIL" name="Email" value="<?php echo $num['Email']; ?>">
  	</div>
	<div class="input-group">
  	  <label>Date</label>
	
  	  <input type="datetime-local" name="Date" value="<?php echo $num['Date']; ?>">
  	</div>
  	<div class="input-group">
  	  <button type="submit" class="btn" name="Upd">Update</button>
  	</div>
  </form>
</body>
</html>