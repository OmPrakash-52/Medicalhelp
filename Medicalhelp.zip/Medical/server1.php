<?php
 session_start();
if(isset($_POST['Lo'])){

	$Name = $_POST['Name'];
	$Password = $_POST['Password'];
	$conn = new mysqli('localhost','root','','medical');
	
	$s="SELECT * FROM dlogin where Name='$Name' && Password='$Password'";
	$result=mysqli_query($conn,$s);
	$num = mysqli_num_rows($result);
	
	if($num == 1){
	$e=mysqli_fetch_array($result);
	$_SESSION['dname']=$e['Name'];
	header('location:next.php');
}
else{
	header('location:Medical.php');
}
}
?>