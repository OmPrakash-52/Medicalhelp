<!DOCTYPE html>

<html>
<head>
  <title>Enter otp</title>
  <link rel="stylesheet" type="text/css" href="style.css">
</head>
<script
  src="https://code.jquery.com/jquery-3.5.1.min.js"
  integrity="sha256-9/aliU8dGd2tb6OSsuzixeV4y/faTqgFtohetphbbj0="
  crossorigin="anonymous"></script>
<body style="background-image: url('medical12.jpg'); background-size:cover;">
  <div class="header">
  	<h2>Enter otp</h2>
  </div>
	
  <form class="header" method="post" action="veri12.php" style="color: black; background: #ffffff; border:1px solid black;">
  	<div class="input-group">
  	  <label>OTP</label>
  	  <input name="OTP" value="">
  	</div>
  	<div class="input-group ">
  	  <button type="submit" class="btn" name="otp1" >Submit</button>
  	</div>
	</form>
  <?php
 session_start();
  if(isset($_POST['otp1'])){
  if($_POST['OTP'] == $_SESSION['otp2']){
  header('location:dsignup.php');
}
else{
 echo '<script type="text/javascript"> alert("wrong otp entered")</script>';
}
}
  ?>
</body>
</html>
