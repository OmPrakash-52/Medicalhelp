<?php
 session_start();
if(isset($_POST['ot'])){

	$email = $_POST['Email'];
	$_SESSION['email3']=$email;
	$conn = new mysqli('localhost','root','','medical');
	$otp=rand(1111,9999);
	$g="INSERT INTO verification (email,otp) VALUES ('$email','$otp')";
	$result=mysqli_query($conn,$g);
	$i =$conn -> query($g);
	if($i){
	 require 'phpmailer/PHPMailerAutoload.php'; //path
    $mail = new PHPMailer;

    //$email = .$Email.; //email where you want to send

    $mail->isSMTP(); //for localhost not liveserver
//if you using latest version of PHP 
$mail->SMTPOptions = array(
'ssl' => array(
'verify_peer' => false,
'verify_peer_name' => false,
'allow_self_signed' => true
)
);

    $mail->Host = 'smtp.gmail.com';
    $mail->port = 587;
    $mail->SMTPAuth = true;
    $mail->SMTPSecure = 'tls';
    $mail->Username = 'medicalhelp142@gmail.com'; //your email id
    $mail->Password = 'hello@world12'; //your email password
    $mail->setFrom('medicalhelp142@gmail.com','Medicalhelp');
    $mail->addAddress($email);
    $mail->addReplyTo('no-reply'); // if you want to reply by user then you can place your email id

    $mail->isHTML(true); //for html
    $mail->Subject = 'Your otp is'; //subject
    
$mail->Body = '<h1 align="center"> hello,Your otp is '.$otp.' </h1>';

if(!$mail->send()) {
        //mail not send
        echo "Mail not send";
        echo "$Email";
    }
    else {
       //mail send
    	$_SESSION['otp2']=$otp;
         header('location:veri12.php');
    } }else{ die($conn->error);}
}
?>
