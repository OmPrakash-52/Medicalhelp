<?php
 session_start();
if(isset($_POST['reg1'])){

	$Name = $_POST['Name'];
	$gender = $_POST['gender'];
	$Pass = $_POST['Pass'];
	$Regis =$_POST['Regis'];
	$Ph = $_POST['Ph'];
	$Email = $_POST['Email'];
	$conn = new mysqli('localhost','root','','medical');
	if($conn->connect_error){
		echo "$conn->connect_error";
		die("Connection Failed : ". $conn->connect_error);
	} else {
		$conn->query("INSERT INTO dlogin (Name,gender1,Password,Registration,Phone1,Email1) VALUES ('$Name','$gender','$Pass','$Regis','$Ph','$Email')") or die($conn->error);
		header('location:dlogin.php');
	}
}
?>