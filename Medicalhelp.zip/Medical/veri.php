<!DOCTYPE html>
<html>
<head>
  <title>Email Verification</title>
  <link rel="stylesheet" type="text/css" href="style.css">
</head>
<script
  src="https://code.jquery.com/jquery-3.5.1.min.js"
  integrity="sha256-9/aliU8dGd2tb6OSsuzixeV4y/faTqgFtohetphbbj0="
  crossorigin="anonymous"></script>
<body style="background-image: url('medical12.jpg'); background-size:cover;">
 <?php require_once 'veri1.php';?>
  <div class="header">
  	<h2>Email Verification</h2>
  </div>
	
  <form class="header" method="post" action="veri.php" style="color: black; background: #ffffff; border:1px solid black;">
  	<div class="input-group first_box">
  	  <label>Email</label>
  	  <input name="Email" value="">
  	</div>
  	<div class="input-group ">
  	  <button type="submit" class="btn" name="ot" >Submit</button>
  	</div>
	</form>
 <!--  <script >
    function send_otp(){
      var email = jQuery('#email').val();
      jQuery.ajax({
        url:'veri1.php',
        type:'post',
        data:'email='+email,
        success:function(result){
  

        }
      });
    }
  </script>
  <style>
    .second_box{display:none;}
  </style> -->
</body>
</html>